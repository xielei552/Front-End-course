<?php
  header("location:home.php?action");
?>