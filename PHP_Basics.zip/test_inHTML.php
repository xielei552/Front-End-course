<html> 
<head> 
<title>PHP Example</title> 
<body> 


<?php
echo '<pre>' ;
print_r(get_loaded_extensions());
phpinfo(); 
?>

</body> 
</html>
