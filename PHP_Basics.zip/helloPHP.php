<!DOCTYPE html>
<html>
<body>

From HTML .. to .. 

<?php
echo "Hello World! My first PHP script.";
?>

</body>
</html>