document.getElementById("foot01").innerHTML =
"<p>&copy;  " + new Date().getFullYear() + " Lei Xie. All rights reserved.</p>";

document.getElementById("nav01").innerHTML =
"<ul id='menu'>" +
"<li><a href='index.html'>Mad Lib</a></li>" +
"</ul>";
