document.getElementById("foot01").innerHTML =
"<p>&copy;  " + new Date().getFullYear() + " Lei Xie. All rights reserved.</p>";

document.getElementById("nav01").innerHTML =
"<ul id='menu'>" +
"<li><a href='index.html'>Home</a></li>" +
"<li><a href='Resume.html'>Resume</a></li>" +
"<li><a href='About.html'>About Me</a></li>" +
"<li><a href='Likes.html'>Likes</a></li>" +
"<li><a href='Gallery.html'>Gallery</a></li>" +
"<li><a href='Contact.html'>Contact</a></li>" +
"</ul>";
